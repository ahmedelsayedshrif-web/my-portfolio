import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Mail, Phone, Linkedin, MapPin, ExternalLink, BarChart3, Database, FileSpreadsheet, TrendingUp, Download, Sparkles, Code2 } from "lucide-react";
import { useEffect, useRef } from "react";

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const aboutRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);
  const projectsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up");
          }
        });
      },
      { threshold: 0.1 }
    );

    [heroRef, aboutRef, skillsRef, projectsRef].forEach((ref) => {
      if (ref.current) observer.observe(ref.current);
    });

    return () => observer.disconnect();
  }, []);

  const skills = {
    dataAnalysis: [
      { name: "Excel", icon: "📊" },
      { name: "Power BI", icon: "📈" },
      { name: "SQL", icon: "🗄️" },
      { name: "Power Query", icon: "🔄" },
      { name: "DAX", icon: "📐" },
      { name: "Python", icon: "🐍" },
      { name: "Minitab", icon: "📉" },
      { name: "Statistical Analysis", icon: "📊" },
      { name: "Data Cleaning", icon: "🧹" }
    ],
    design: [
      { name: "Figma", icon: "🎨" },
      { name: "Photoshop", icon: "🖼️" },
      { name: "Illustrator", icon: "✏️" },
      { name: "Data Visualization", icon: "📊" },
      { name: "Dashboard Design", icon: "🎯" }
    ],
    tools: [
      { name: "Microsoft Office", icon: "📄" },
      { name: "Google Sheets", icon: "📑" },
      { name: "VBA", icon: "⚙️" },
      { name: "Adobe Creative Suite", icon: "🎨" },
      { name: "Canva", icon: "🖌️" }
    ],
    soft: [
      { name: "Problem Solving", icon: "💡" },
      { name: "Team Work", icon: "🤝" },
      { name: "Time Management", icon: "⏰" },
      { name: "Communication", icon: "💬" },
      { name: "Analytical Thinking", icon: "🧠" }
    ]
  };

  const projects = [
    {
      title: "SQL BikeStores Database Analysis",
      description: "Completed an end-to-end SQL Data Analysis and Business Intelligence project using the BikeStores sample database. Built the entire database structure from scratch with SQL code, designed ERD to map relationships and business logic, and imported real business data for realistic analytical insights. Extracted business insights by writing, optimizing, and running advanced SQL queries to answer practical business questions.",
      image: "/project-sql-bikestores.png",
      achievements: [
        "Designed complete ERD mapping all relationships and business logic",
        "Built entire database structure from scratch with SQL",
        "Solved real-world data challenges including import errors and constraints",
        "Extracted actionable business insights through advanced SQL queries"
      ],
      skills: ["SQL", "Database Design", "ERD", "Business Intelligence", "Data Analysis", "SSMS"],
      icon: Database,
      color: "from-blue-600 to-cyan-600"
    },
    {
      title: "Workforce Analytics Dashboard",
      description: "Built a complete end-to-end Workforce Analytics project using Power BI, covering everything from raw data cleanup to an interactive, decision-ready dashboard. Created an interactive dashboard to analyze employee performance, satisfaction, and identify root causes of attrition to help HR and leadership make data-driven decisions. Designed dashboard background and mockups in Figma for a polished UI.",
      image: "/project-workforce-analytics.png",
      achievements: [
        "Implemented Star Schema data modeling with fact and dimension tables",
        "Created 10+ core DAX measures including Attrition Rate and High Performers Count",
        "Built 2-page interactive dashboard with slicers and navigation buttons",
        "Solved data quality issues with dynamic Date table and conditional columns"
      ],
      skills: ["Power BI", "Power Query", "DAX", "Figma", "Data Modeling", "Star Schema"],
      icon: BarChart3,
      color: "from-purple-600 to-pink-600"
    },
    {
      title: "Full Data Analysis Project - Power BI",
      description: "Completed a comprehensive end-to-end Data Analysis project delivering a professional interactive dashboard. Performed data cleaning and preparation using Power Query (standardization, missing value handling, ETL), built robust Data Model to correctly relate tables for reliable calculations, and created advanced Measures & calculations using DAX for accurate KPIs. Designed dashboard background & mockups in Figma for polished UI/UX.",
      image: "/project-data-analysis-powerbi.png",
      achievements: [
        "Consolidated messy datasets into a trustworthy analytics source",
        "Built interactive visualizations (KPIs, maps, time series, bar & donut charts)",
        "Created decision-ready dashboard presenting clear KPIs with interactive controls",
        "Delivered actionable insights enabling faster, data-driven decisions"
      ],
      skills: ["Power BI", "Power Query", "DAX", "Figma", "Data Visualization", "Business Intelligence"],
      icon: TrendingUp,
      color: "from-indigo-600 to-blue-600"
    },
    {
      title: "Sales Dashboard - Power BI",
      description: "Built a simple yet effective Sales Dashboard as part of my data journey, highlighting main KPIs including Total Revenue (8.58M), Orders (1.6K), and Total Quantity (7K). Delivered information in a clear, actionable way to support decision-making with focus on Mountain Bikes category performance.",
      image: "/project-sales-dashboard.png",
      achievements: [
        "Created clean KPI cards for quick insights",
        "Visualized sales revenue by category showing Mountain Bikes leading performance",
        "Designed professional dark-themed dashboard for better readability",
        "Demonstrated ability to transform data into actionable business insights"
      ],
      skills: ["Power BI", "Dashboard Design", "Data Visualization", "KPI Development"],
      icon: BarChart3,
      color: "from-cyan-600 to-teal-600"
    },
    {
      title: "Excel Data Analysis Project",
      description: "Completed a major milestone in my data journey with a full Data Analysis project using Excel. Performed data cleaning & preparation with Power Query (ETL & cleanup), built Power Pivot data model, created Pivot Tables for actionable insights, and designed an interactive dashboard with slicers. Delivered a consolidated dashboard presenting clear KPIs (Sales, Profit, Top Products, Ship Modes) with interactive controls for fast filtering.",
      image: "/project-excel-analysis.png",
      achievements: [
        "Cleaned & consolidated data sources with Power Query",
        "Built professional Pivot Tables with strong Power Pivot model",
        "Removed unnecessary columns and filled missing categories via Product ID lookup",
        "Designed interactive dashboard analyzing Sales, Profit, and Regional performance"
      ],
      skills: ["Excel", "Power Query", "Power Pivot", "Pivot Tables", "Dashboard Design", "ETL"],
      icon: FileSpreadsheet,
      color: "from-green-600 to-emerald-600"
    }
  ];

  const experiences = [
    {
      title: "Senior Graphic Designer (Freelance)",
      period: "Aug 2024 - Present",
      description: "Specialized in social media design and branding using Photoshop and Illustrator. Applied design thinking and visual analytics to optimize brand messaging. Created data-driven design strategies by analyzing engagement metrics.",
      achievements: [
        "Managed 15+ client projects with 100% on-time delivery rate",
        "Increased client social media engagement by 35% through strategic visual design",
        "Applied visual analytics to optimize brand performance"
      ]
    },
    {
      title: "Data Entry Specialist at EgyPort",
      period: "Jul 2024 - Oct 2024",
      description: "Organized and cleaned customs data in Excel, ensuring data accuracy and integrity for import/export operations. Implemented data validation systems and systematic cleaning processes.",
      achievements: [
        "Improved data accuracy rate to 98% through systematic validation processes",
        "Reduced document processing time by 30% through Excel automation",
        "Developed data cleaning workflows for customs documentation"
      ]
    }
  ];

  const toolIcons = [
    { name: "Power BI", color: "text-yellow-500" },
    { name: "Excel", color: "text-green-500" },
    { name: "SQL", color: "text-blue-500" },
    { name: "Python", color: "text-yellow-400" },
    { name: "Figma", color: "text-purple-500" },
    { name: "Photoshop", color: "text-blue-400" }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950/20 via-purple-950/20 to-cyan-950/20"></div>
        <div 
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: 'url(/data-bg-1.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            animation: 'float 20s ease-in-out infinite'
          }}
        ></div>
        <div className="absolute inset-0 backdrop-blur-3xl bg-background/95"></div>
        
        {/* Animated particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-primary/20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `particle ${5 + Math.random() * 10}s linear infinite`,
                animationDelay: `${Math.random() * 5}s`
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Navigation */}
        <nav className="fixed top-0 left-0 right-0 z-50 bg-background/60 backdrop-blur-xl border-b border-border/50">
          <div className="container mx-auto px-6 py-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-blue-400 to-cyan-400 bg-clip-text text-transparent">
                Ahmed Sherif
              </h1>
              <div className="flex gap-6 items-center">
                <a href="#about" className="hover:text-primary transition-colors hidden md:block">About</a>
                <a href="#skills" className="hover:text-primary transition-colors hidden md:block">Skills</a>
                <a href="#projects" className="hover:text-primary transition-colors hidden md:block">Projects</a>
                <a href="#contact" className="hover:text-primary transition-colors hidden md:block">Contact</a>
                <Button asChild size="sm" variant="outline" className="group">
                  <a href="/Ahmed-Sherif-CV.pdf" download>
                    <Download className="mr-2 h-4 w-4 group-hover:animate-bounce" />
                    Download CV
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section ref={heroRef} className="min-h-screen flex items-center justify-center pt-20 opacity-0">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="space-y-2">
                  <p className="text-primary text-lg font-medium flex items-center gap-2">
                    <Sparkles className="h-5 w-5" />
                    Data Analyst & Visualization Expert
                  </p>
                  <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary via-blue-400 to-cyan-400 bg-clip-text text-transparent leading-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Ahmed Elsayed Sherif
                  </h1>
                  <p className="text-2xl md:text-3xl text-muted-foreground font-semibold">
                    Power BI | Excel | SQL Specialist
                  </p>
                </div>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Transforming raw data into actionable business insights through advanced analytics, 
                  professional visualization, and strategic problem-solving. Expert in Power BI dashboard design, 
                  SQL data analysis, and creating compelling data stories with Figma.
                </p>
                
                {/* Tool Icons */}
                <div className="flex flex-wrap gap-3 py-4">
                  {toolIcons.map((tool, index) => (
                    <div
                      key={index}
                      className={`px-4 py-2 rounded-lg bg-card/50 backdrop-blur border border-border/50 hover:border-primary/50 transition-all duration-300 hover:scale-110 ${tool.color} font-semibold text-sm`}
                    >
                      {tool.name}
                    </div>
                  ))}
                </div>

                <div className="flex gap-4">
                  <Button asChild size="lg" className="group bg-gradient-to-r from-primary to-blue-500 hover:from-primary/90 hover:to-blue-500/90">
                    <a href="#contact">
                      Get In Touch
                      <ExternalLink className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </a>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="border-primary/50 hover:bg-primary/10">
                    <a href="#projects">View Projects</a>
                  </Button>
                </div>
                <div className="flex gap-4 pt-4">
                  <a href="mailto:ahmedelsayedshrif@gmail.com" className="hover:text-primary transition-colors hover:scale-110 transform duration-200">
                    <Mail className="h-6 w-6" />
                  </a>
                  <a href="https://www.linkedin.com/in/ahmed-s-sherif" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors hover:scale-110 transform duration-200">
                    <Linkedin className="h-6 w-6" />
                  </a>
                </div>
              </div>
              <div className="relative">
                <div className="relative w-full aspect-[3/4] max-w-md mx-auto">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-blue-500/20 to-cyan-500/30 rounded-3xl blur-3xl animate-pulse"></div>
                  <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-cyan-500/20 rounded-3xl blur-2xl opacity-50"></div>
                  <img 
                    src="/ahmed-photo.png" 
                    alt="Ahmed Sherif" 
                    className="relative z-10 w-full h-full object-cover object-center rounded-3xl shadow-2xl border-2 border-primary/20"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" ref={aboutRef} className="py-20 opacity-0">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">About Me</h2>
            <div className="grid md:grid-cols-2 gap-12">
              <Card className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5 text-primary" />
                    Professional Background
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed">
                    Developed and delivered multiple data analysis projects using Excel, Power BI, Power Query, DAX, and SQL. 
                    Applied analytical, problem-solving, and statistical skills to transform raw data into actionable business insights.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    Expert in <span className="text-primary font-semibold">data visualization</span> and <span className="text-primary font-semibold">dashboard design using Figma</span>, 
                    creating intuitive and impactful visual stories that drive business decisions. Currently advancing skills in SQL and Python 
                    while seeking opportunities to contribute to data-driven decision making in leading organizations.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileSpreadsheet className="h-5 w-5 text-primary" />
                    Education
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg">Bachelor's Degree in Accounting</h3>
                    <p className="text-muted-foreground">Damietta University</p>
                    <p className="text-sm text-muted-foreground">Sep 2023 - May 2027</p>
                  </div>
                  <div className="pt-4">
                    <h3 className="font-semibold mb-2">Languages</h3>
                    <div className="flex gap-2">
                      <Badge variant="secondary" className="bg-primary/10 hover:bg-primary/20">Arabic (Native)</Badge>
                      <Badge variant="secondary" className="bg-primary/10 hover:bg-primary/20">English (Fluent)</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-12 space-y-6">
              <h3 className="text-2xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">Experience</h3>
              <div className="grid md:grid-cols-2 gap-6">
                {experiences.map((exp, index) => (
                  <Card key={index} className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10">
                    <CardHeader>
                      <CardTitle>{exp.title}</CardTitle>
                      <CardDescription className="text-primary">{exp.period}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-muted-foreground">{exp.description}</p>
                      <ul className="space-y-2">
                        {exp.achievements.map((achievement, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" ref={skillsRef} className="py-20 opacity-0">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">Technical Skills</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 md:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Data Analysis & Databases
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skills.dataAnalysis.map((skill) => (
                      <Badge key={skill.name} variant="secondary" className="hover:bg-primary hover:text-primary-foreground transition-colors text-sm py-1.5 px-3">
                        <span className="mr-1">{skill.icon}</span>
                        {skill.name}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    Design & Visualization
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skills.design.map((skill) => (
                      <Badge key={skill.name} variant="secondary" className="hover:bg-primary hover:text-primary-foreground transition-colors text-sm py-1.5 px-3">
                        <span className="mr-1">{skill.icon}</span>
                        {skill.name}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10">
                <CardHeader>
                  <CardTitle>Tools & Software</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skills.tools.map((skill) => (
                      <Badge key={skill.name} variant="secondary" className="hover:bg-primary hover:text-primary-foreground transition-colors text-sm py-1.5 px-3">
                        <span className="mr-1">{skill.icon}</span>
                        {skill.name}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:shadow-primary/10 md:col-span-2">
                <CardHeader>
                  <CardTitle>Soft Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skills.soft.map((skill) => (
                      <Badge key={skill.name} variant="secondary" className="hover:bg-primary hover:text-primary-foreground transition-colors text-sm py-1.5 px-3">
                        <span className="mr-1">{skill.icon}</span>
                        {skill.name}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" ref={projectsRef} className="py-20 opacity-0">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">Featured Projects</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {projects.map((project, index) => {
                const Icon = project.icon;
                return (
                  <Card key={index} className="bg-card/30 backdrop-blur-xl border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-2xl hover:shadow-primary/20 group overflow-hidden">
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <CardTitle className="text-xl group-hover:text-primary transition-colors flex-1">{project.title}</CardTitle>
                        <div className={`p-3 rounded-xl bg-gradient-to-br ${project.color} group-hover:scale-110 transition-transform duration-300 flex-shrink-0`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-muted-foreground leading-relaxed text-sm">{project.description}</p>
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2 text-sm">
                          <span className="text-primary">✨</span>
                          Key Achievements:
                        </h4>
                        <ul className="space-y-1.5">
                          {project.achievements.map((achievement, i) => (
                            <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                              <span className="text-primary mt-0.5">•</span>
                              <span>{achievement}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2 text-sm">Technologies Used:</h4>
                        <div className="flex flex-wrap gap-1.5">
                          {project.skills.map((skill) => (
                            <Badge key={skill} variant="outline" className="border-primary/50 hover:bg-primary hover:text-primary-foreground transition-colors text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent">Get In Touch</h2>
            <Card className="max-w-2xl mx-auto bg-card/30 backdrop-blur-xl border-border/50">
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-background/30 hover:bg-background/50 transition-colors border border-border/30 hover:border-primary/50">
                    <Mail className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold">Email</p>
                      <a href="mailto:ahmedelsayedshrif@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">
                        ahmedelsayedshrif@gmail.com
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-background/30 hover:bg-background/50 transition-colors border border-border/30 hover:border-primary/50">
                    <Phone className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold">Phone</p>
                      <a href="tel:+201060161524" className="text-muted-foreground hover:text-primary transition-colors">
                        +20 106 016 1524
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-background/30 hover:bg-background/50 transition-colors border border-border/30 hover:border-primary/50">
                    <Linkedin className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold">LinkedIn</p>
                      <a href="https://www.linkedin.com/in/ahmed-s-sherif" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                        linkedin.com/in/ahmed-s-sherif
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 rounded-lg bg-background/30 hover:bg-background/50 transition-colors border border-border/30 hover:border-primary/50">
                    <MapPin className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold">Location</p>
                      <p className="text-muted-foreground">New Damietta, Egypt</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 border-t border-border/50 bg-background/30 backdrop-blur-xl">
          <div className="container mx-auto px-6 text-center text-muted-foreground">
            <p>© 2024 Ahmed Elsayed Sherif. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
